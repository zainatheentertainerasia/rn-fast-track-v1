/* LTR */
export { default as en } from './en';
/* RTL */
export { default as ar } from './ar';
