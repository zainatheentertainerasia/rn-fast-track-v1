export default {
	...require('./generic/common.json'),
};
